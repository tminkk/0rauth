# Hướng dẫn Tích hợp Xác thực Bản quyền C++ (0rauth Integration Guide)

Tài liệu này hướng dẫn cách kết nối ứng dụng C++ (trên Windows) của bạn với License Server **0rauth** để xác thực key và khóa thiết bị (HWID Lock).

---

## ⚙️ Quy trình Xác thực hoạt động thế nào?

```mermaid
sequenceDiagram
    participant Client as Ứng dụng C++
    participant Server as Hono License Server
    Client->>Client: 1. Lấy thông tin thiết bị (HWID)
    Client->>Client: 2. Nhập License Key từ người dùng
    Client->>Server: 3. Gửi POST /api/verify-license (key, hwid)
    Note over Server: Kiểm tra: Tồn tại?, Hết hạn?,<br/>Banned?, Trùng HWID?
    Server-->>Client: 4. Trả về JSON { valid: true/false }
    alt Valid là true
        Client->>Client: Chạy ứng dụng chính
    else Valid là false
        Client->>Client: Thoát ứng dụng & báo lỗi
    end
```

---

## 💻 Mã nguồn C++ Mẫu (Windows)

Để thuận tiện nhất và **không cần cài thêm thư viện ngoài (như libcurl)**, mã nguồn dưới đây sử dụng thư viện mạng có sẵn của Windows là **`WinINet`** để thực hiện cuộc gọi API HTTP POST, và đọc Registry để sinh chuỗi phần cứng **HWID** độc nhất cho mỗi máy tính Windows.

### 📝 Mã nguồn tích hợp đầy đủ (`main.cpp`):

```cpp
#include <windows.h>
#include <wininet.h>
#include <iostream>
#include <string>
#include <sstream>

#pragma comment(lib, "wininet.lib")

// --- 1. HÀM LẤY HWID ĐỘC NHẤT TRÊN WINDOWS ---
// Đọc MachineGuid từ Registry Windows để làm HWID định danh thiết bị
std::string GetMachineHWID() {
    char buffer[256] = { 0 };
    DWORD bufferSize = sizeof(buffer);
    HKEY hKey;
    
    // Đường dẫn tới MachineGuid của Windows Registry
    LPCSTR subkey = "SOFTWARE\\Microsoft\\Cryptography";
    
    if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, subkey, 0, KEY_READ | KEY_WOW64_64KEY, &hKey) == ERROR_SUCCESS) {
        if (RegQueryValueExA(hKey, "MachineGuid", NULL, NULL, (LPBYTE)buffer, &bufferSize) == ERROR_SUCCESS) {
            RegCloseKey(hKey);
            return std::string(buffer);
        }
        RegCloseKey(hKey);
    }
    return "UNKNOWN_HWID";
}

// --- 2. HÀM THỰC HIỆN HTTP POST REQUEST (WinINet) ---
// Gửi JSON lên Server và nhận kết quả JSON phản hồi
std::string SendPostRequest(const std::string& host, int port, const std::string& path, const std::string& jsonPayload) {
    std::string response = "";
    
    HINTERNET hInternet = InternetOpenA("0rAuthClient", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!hInternet) return "{\"error\":\"Lỗi kết nối mạng ban đầu\"}";
    
    HINTERNET hConnect = InternetConnectA(hInternet, host.c_str(), port, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
    if (!hConnect) {
        InternetCloseHandle(hInternet);
        return "{\"error\":\"Không thể kết nối đến máy chủ\"}";
    }
    
    LPCSTR acceptTypes[] = { "application/json", NULL };
    HINTERNET hRequest = HttpOpenRequestA(hConnect, "POST", path.c_str(), NULL, NULL, acceptTypes, INTERNET_FLAG_RELOAD | INTERNET_FLAG_SECURE, 0);
    if (!hRequest) {
        // Fallback sang HTTP nếu HTTPS thất bại hoặc server không có SSL
        hRequest = HttpOpenRequestA(hConnect, "POST", path.c_str(), NULL, NULL, acceptTypes, INTERNET_FLAG_RELOAD, 0);
    }
    
    if (hRequest) {
        std::string headers = "Content-Type: application/json\r\n";
        BOOL sent = HttpSendRequestA(hRequest, headers.c_str(), headers.length(), (LPVOID)jsonPayload.c_str(), jsonPayload.length());
        
        if (sent) {
            char buffer[1024];
            DWORD bytesRead = 0;
            while (InternetReadFile(hRequest, buffer, sizeof(buffer) - 1, &bytesRead) && bytesRead > 0) {
                buffer[bytesRead] = '\0';
                response += buffer;
            }
        } else {
            response = "{\"error\":\"Gửi request thất bại\"}";
        }
        InternetCloseHandle(hRequest);
    }
    
    InternetCloseHandle(hConnect);
    InternetCloseHandle(hInternet);
    return response;
}

// --- 3. HÀM XỬ LÝ SO KHỚP CHUỖI JSON ĐƠN GIẢN ---
// Trích xuất giá trị trường "valid" từ chuỗi JSON thô (tránh cài đặt thêm thư viện nlohmann/json)
bool ParseValidFromJson(const std::string& json) {
    size_t pos = json.find("\"valid\":");
    if (pos != std::string::npos) {
        std::string sub = json.substr(pos + 8);
        if (sub.find("true") == 0 || sub.find(" true") == 0) {
            return true;
        }
    }
    return false;
}

std::string ParseErrorFromJson(const std::string& json) {
    size_t pos = json.find("\"error\":\"");
    if (pos != std::string::npos) {
        size_t start = pos + 9;
        size_t end = json.find("\"", start);
        if (end != std::string::npos) {
            return json.substr(start, end - start);
        }
    }
    return "Lỗi không xác định";
}

// --- 4. HÀM CHÍNH (MAIN ENTRY) ---
int main() {
    // Thiết lập font UTF-8 để hiển thị tiếng Việt trên Console
    SetConsoleOutputCP(CP_UTF8);
    
    std::cout << "=== HỆ THỐNG XÁC THỰC BẢN QUYỀN SOFTWARE ===" << std::endl;
    
    // Lấy HWID độc nhất của máy
    std::string myHwid = GetMachineHWID();
    std::cout << "[+] HWID của thiết bị: " << myHwid << std::endl;
    
    // Nhập Key bản quyền
    std::cout << "[?] Vui lòng nhập License Key: ";
    std::string licenseKey;
    std::cin >> licenseKey;
    
    std::cout << "[*] Đang kết nối server để xác thực..." << std::endl;
    
    // Đóng gói JSON Payload
    std::stringstream ss;
    ss << "{\"licenseKey\":\"" << licenseKey << "\",\"hwid\":\"" << myHwid << "\"}";
    std::string payload = ss.str();
    
    // Gửi request lên Server Hono (Ví dụ chạy ở localhost cổng 3000)
    // Thay đổi "localhost" thành IP Server thực tế của bạn khi deploy
    std::string response = SendPostRequest("localhost", 3000, "/api/verify-license", payload);
    
    std::cout << "[+] Server Phản hồi: " << response << std::endl;
    
    // Phân tích kết quả
    if (ParseValidFromJson(response)) {
        std::cout << "\n==============================================" << std::endl;
        std::cout << "✅ BẢN QUYỀN HỢP LỆ! Chào mừng bạn sử dụng phần mềm." << std::endl;
        std::cout << "==============================================" << std::endl;
        
        // CHẠY CHƯƠNG TRÌNH CHÍNH CỦA BẠN TẠI ĐÂY...
        system("pause");
    } else {
        std::string errReason = ParseErrorFromJson(response);
        std::cout << "\n==============================================" << std::endl;
        std::cout << "❌ BẢN QUYỀN KHÔNG HỢP LỆ!" << std::endl;
        std::cout << "👉 Lý do: " << errReason << std::endl;
        std::cout << "==============================================" << std::endl;
        
        system("pause");
        exit(1); // Thoát chương trình
    }
    
    return 0;
}
```

---

## 🛡️ Khuyến nghị Bảo mật (Anti-Crack & Anti-Bypass)

Nếu bạn phân phối phần mềm thương mại, những hacker có thể dùng phần mềm dịch ngược (Reverse Engineering) như **IDA Pro**, **x64dbg** để bypass đoạn check bản quyền. Bạn nên áp dụng các quy chuẩn bảo mật sau:

1.  **Obfuscate (Ẩn giấu) API Endpoint**:
    Không nên để chuỗi `"http://localhost:3000/api/verify-license"` hay `/api/verify-license` ở dạng bản rõ (plaintext). Hãy mã hóa nó bằng XOR đơn giản trong C++ trước khi gửi để tránh bị hacker dò quét chuỗi (String Scanning).
2.  **Anti-Debugging**:
    Thêm đoạn kiểm tra xem chương trình có đang bị chạy dưới trình gỡ lỗi (debugger) hay không bằng hàm API có sẵn của Windows:
    ```cpp
    if (IsDebuggerPresent()) {
        ExitProcess(0); // Tự động thoát nếu bị gỡ lỗi
    }
    ```
3.  **Mã hóa gói tin trả về (Không bắt buộc nhưng khuyến khích)**:
    Nếu muốn bảo mật tuyệt đối, bạn có thể mã hóa JSON trả về của server Hono bằng thuật toán AES, và Client C++ sẽ giải mã nó. Việc này ngăn chặn hacker sửa file `hosts` để hướng domain server của bạn về `localhost` và giả lập một response `{ "valid": true }` giả mạo.
