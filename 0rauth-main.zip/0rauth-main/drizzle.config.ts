import { defineConfig } from "drizzle-kit";
import * as dotenv from "dotenv";

dotenv.config();

if (!process.env.DATABASE_URL) {
    console.error("❌ LỖI CONFIG: Chưa cấu hình DATABASE_URL trong file .env");
}

export default defineConfig({
    dialect: "postgresql",
    schema: "./src/db.ts",
    out: "./drizzle",
    dbCredentials: {
        url: process.env.DATABASE_URL || "",
    },
});
