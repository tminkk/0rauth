/* public/app.js */

// --- 1. BIẾN TOÀN CỤC VÀ KHỞI TẠO CẤU HÌNH ---
const API_URL = window.location.origin;
let currentUser = null;
let currentLicenses = [];

// Các Element trong DOM
const el = {
    authScreen: document.getElementById('auth-screen'),
    dashboardScreen: document.getElementById('dashboard-screen'),
    loginForm: document.getElementById('login-form'),
    authTitle: document.getElementById('auth-title'),
    adminEmail: document.getElementById('admin-email'),
    btnLogout: document.getElementById('btn-logout'),
    
    // Thống kê
    statTotal: document.getElementById('stat-total'),
    statActive: document.getElementById('stat-active'),
    statBanned: document.getElementById('stat-banned'),
    
    // Bảng dữ liệu
    licenseTableBody: document.getElementById('license-table-body'),
    btnRefresh: document.getElementById('btn-refresh'),
    
    // Modal tạo Key
    btnOpenCreate: document.getElementById('btn-open-create'),
    createModal: document.getElementById('create-modal'),
    btnCloseModal: document.getElementById('btn-close-modal'),
    btnCancelModal: document.getElementById('btn-cancel-modal'),
    createLicenseForm: document.getElementById('create-license-form'),
    licenseDays: document.getElementById('license-days'),
    generatedKeyContainer: document.getElementById('generated-key-container'),
    generatedKeyText: document.getElementById('generated-key-text'),
    btnCopyGenKey: document.getElementById('btn-copy-gen-key'),
    
    // Toast
    toast: document.getElementById('toast'),
    toastMessage: document.getElementById('toast-message'),
    toastIcon: document.getElementById('toast-icon')
};

// --- 2. HÀM TIỆN ÍCH HỆ THỐNG ---

// Hiển thị Toast thông báo
function showToast(message, type = 'info') {
    el.toastMessage.textContent = message;
    
    // Đổi màu viền tùy thuộc loại thông báo
    if (type === 'success') {
        el.toast.style.borderLeftColor = 'var(--success)';
        el.toastIcon.setAttribute('data-lucide', 'check-circle-2');
        el.toastIcon.style.color = 'var(--success)';
    } else if (type === 'error') {
        el.toast.style.borderLeftColor = 'var(--danger)';
        el.toastIcon.setAttribute('data-lucide', 'alert-triangle');
        el.toastIcon.style.color = 'var(--danger)';
    } else {
        el.toast.style.borderLeftColor = 'var(--primary)';
        el.toastIcon.setAttribute('data-lucide', 'info');
        el.toastIcon.style.color = 'var(--primary)';
    }
    
    lucide.createIcons(); // Vẽ lại icon mới nạp vào Toast
    
    el.toast.classList.remove('hidden');
    el.toast.style.opacity = '1';
    el.toast.style.transform = 'translateY(0)';
    
    setTimeout(() => {
        el.toast.style.opacity = '0';
        el.toast.style.transform = 'translateY(10px)';
        setTimeout(() => el.toast.classList.add('hidden'), 300);
    }, 3500);
}

// Sao chép văn bản vào Clipboard
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        showToast('Đã copy mã key vào bộ nhớ tạm!', 'success');
    } catch {
        showToast('Lỗi! Không thể copy tự động.', 'error');
    }
}

// Khởi chạy vẽ lại Lucide Icons
function updateIcons() {
    lucide.createIcons();
}

// Chuyển đổi màn hình giao diện
function showScreen(screen) {
    el.authScreen.classList.add('hidden');
    el.dashboardScreen.classList.add('hidden');
    
    if (screen === 'auth') {
        el.authScreen.classList.remove('hidden');
    } else if (screen === 'dashboard') {
        el.dashboardScreen.classList.remove('hidden');
    }
    updateIcons();
}

// --- 3. XỬ LÝ GỌI API (AUTHENTICATION & ADMINISTRATION) ---



// Đăng nhập tài khoản (Better-Auth)
async function loginUser(email, password) {
    try {
        const res = await fetch(`${API_URL}/api/auth/sign-in/email`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const data = await res.json();
        if (!res.ok) {
            throw new Error(data.message || 'Sai tài khoản hoặc mật khẩu.');
        }
        
        showToast('Đăng nhập thành công!', 'success');
        await checkSessionAndLoad();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// Kiểm tra Session hiện tại
async function checkSessionAndLoad() {
    try {
        // Better-Auth API tự động gửi Cookie kèm theo
        const res = await fetch(`${API_URL}/api/auth/get-session`);
        if (!res.ok) return showScreen('auth');
        
        const data = await res.json().catch(() => null);
        if (data && data.user) {
            currentUser = data.user;
            
            // Chỉ cho phép người dùng có quyền Admin truy cập Dashboard
            if (currentUser.role !== 'admin') {
                showToast('Bạn không phải là Quản trị viên!', 'error');
                await logoutUser(false);
                return;
            }
            
            el.adminEmail.textContent = currentUser.email;
            showScreen('dashboard');
            await loadLicenses();
        } else {
            showScreen('auth');
        }
    } catch (err) {
        console.error('Error checking session:', err);
        showScreen('auth');
    }
}

// Đăng xuất tài khoản
async function logoutUser(showNotification = true) {
    try {
        await fetch(`${API_URL}/api/auth/sign-out`, { method: 'POST' });
        currentUser = null;
        if (showNotification) showToast('Đã đăng xuất khỏi hệ thống.');
        showScreen('auth');
    } catch (err) {
        console.error('Sign-out error:', err);
        showScreen('auth');
    }
}

// Lấy danh sách Licenses của Admin
async function loadLicenses() {
    try {
        const res = await fetch(`${API_URL}/api/admin/licenses`);
        if (!res.ok) {
            const data = await res.json().catch(() => ({}));
            throw new Error(data.error || 'Không thể lấy dữ liệu License');
        }
        
        currentLicenses = await res.json();
        renderLicenses();
    } catch (err) {
        showToast(err.message, 'error');
    }
}

// Hiển thị danh sách License ra bảng dữ liệu
function renderLicenses() {
    el.licenseTableBody.innerHTML = '';
    
    // Tính toán chỉ số thống kê
    const total = currentLicenses.length;
    const banned = currentLicenses.filter(k => k.status === 'banned').length;
    const active = currentLicenses.filter(k => {
        const isExpired = new Date() > new Date(k.expiresAt);
        return k.status === 'active' && !isExpired;
    }).length;
    
    el.statTotal.textContent = total;
    el.statActive.textContent = active;
    el.statBanned.textContent = banned;

    if (total === 0) {
        el.licenseTableBody.innerHTML = `
            <tr>
                <td colspan="5" class="table-empty">Hệ thống chưa tạo key bản quyền nào. Hãy tạo key đầu tiên!</td>
            </tr>
        `;
        return;
    }
    
    // Sắp xếp key mới tạo lên đầu
    const sortedKeys = [...currentLicenses].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    sortedKeys.forEach(license => {
        const expiresDate = new Date(license.expiresAt);
        const isExpired = new Date() > expiresDate;
        
        // Xác định Badge trạng thái
        let statusBadge = `<span class="badge badge-active">Active</span>`;
        if (license.status === 'banned') {
            statusBadge = `<span class="badge badge-banned">Banned</span>`;
        } else if (isExpired) {
            statusBadge = `<span class="badge badge-expired">Expired</span>`;
        }
        
        // Cột HWID
        let hwidContent = `<span class="hwid-empty">Chưa kích hoạt</span>`;
        if (license.hwid) {
            hwidContent = `
                <div class="hwid-cell">
                    <span class="hwid-badge" title="${license.hwid}">${license.hwid.substring(0, 12)}...</span>
                    <button class="btn-action-icon" onclick="resetHwid('${license.id}')" title="Reset HWID (Mở khóa thiết bị)">
                        <i data-lucide="refresh-cw"></i>
                    </button>
                </div>
            `;
        }
        
        // Nút Ban / Unban
        const isBanned = license.status === 'banned';
        const banButton = `
            <button class="btn-action-icon ban ${isBanned ? 'unban' : 'ban'}" 
                    onclick="toggleBan('${license.id}', '${isBanned ? 'active' : 'banned'}')" 
                    title="${isBanned ? 'Mở khóa Key' : 'Khóa (Ban) Key'}">
                <i data-lucide="${isBanned ? 'unlock' : 'ban'}"></i>
            </button>
        `;
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                <div class="key-cell">
                    <code>${license.key}</code>
                    <button class="btn-copy" onclick="copyToClipboard('${license.key}')" title="Copy Key">
                        <i data-lucide="copy"></i>
                    </button>
                </div>
            </td>
            <td>${hwidContent}</td>
            <td>${expiresDate.toLocaleDateString('vi-VN')} ${expiresDate.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}</td>
            <td>${statusBadge}</td>
            <td>
                <div class="actions-cell">
                    ${banButton}
                    <button class="btn-action-icon delete" onclick="deleteLicense('${license.id}')" title="Xóa vĩnh viễn Key">
                        <i data-lucide="trash-2"></i>
                    </button>
                </div>
            </td>
        `;
        el.licenseTableBody.appendChild(row);
    });
    
    updateIcons();
}

// Khóa hoặc mở khóa một Key
window.toggleBan = async (licenseId, targetStatus) => {
    const confirmMsg = targetStatus === 'banned' 
        ? 'Bạn chắc chắn muốn KHÓA (Ban) key bản quyền này? Phần mềm client sẽ không thể xác thực.' 
        : 'Bạn muốn MỞ KHÓA key bản quyền này?';
        
    if (!confirm(confirmMsg)) return;
    
    try {
        const res = await fetch(`${API_URL}/api/admin/licenses/ban`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ licenseId, status: targetStatus })
        });
        
        if (!res.ok) throw new Error('Không thể cập nhật trạng thái Key.');
        showToast('Cập nhật trạng thái key thành công!', 'success');
        await loadLicenses();
    } catch (err) {
        showToast(err.message, 'error');
    }
};

// Reset HWID (Xóa liên kết thiết bị cũ)
window.resetHwid = async (licenseId) => {
    if (!confirm('Bạn có chắc muốn Reset thiết bị phần cứng của key này? Key sẽ có thể được kích hoạt trên thiết bị khác.')) return;
    
    try {
        const res = await fetch(`${API_URL}/api/admin/licenses/reset-hwid`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ licenseId })
        });
        
        if (!res.ok) throw new Error('Không thể reset HWID.');
        showToast('Reset liên kết phần cứng thành công!', 'success');
        await loadLicenses();
    } catch (err) {
        showToast(err.message, 'error');
    }
};

// Xóa License vĩnh viễn
window.deleteLicense = async (licenseId) => {
    if (!confirm('HÀNH ĐỘNG KHÔNG THỂ KHÔI PHỤC: Bạn chắc chắn muốn xóa vĩnh viễn key bản quyền này?')) return;
    
    try {
        const res = await fetch(`${API_URL}/api/admin/licenses`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ licenseId })
        });
        
        if (!res.ok) throw new Error('Xóa key thất bại.');
        showToast('Xóa key bản quyền vĩnh viễn thành công.', 'success');
        await loadLicenses();
    } catch (err) {
        showToast(err.message, 'error');
    }
};

// --- 4. SỰ KIỆN XỬ LÝ LẮNG NGHE (EVENT LISTENERS) ---

// Xử lý gửi Form Đăng nhập
el.loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    await loginUser(email, password);
});

// Nút Đăng xuất
el.btnLogout.addEventListener('click', async () => {
    if (confirm('Bạn có chắc muốn đăng xuất?')) {
        await logoutUser();
    }
});

// Nút làm mới danh sách Key
el.btnRefresh.addEventListener('click', async () => {
    el.btnRefresh.style.animation = 'spin 0.6s linear';
    setTimeout(() => el.btnRefresh.style.animation = '', 600);
    await loadLicenses();
});

// Sự kiện đóng mở Modal tạo License
el.btnOpenCreate.addEventListener('click', () => {
    el.generatedKeyContainer.classList.add('hidden');
    el.createLicenseForm.reset();
    el.createModal.classList.remove('hidden');
    el.licenseDays.focus();
});

const closeModal = () => {
    el.createModal.classList.add('hidden');
    loadLicenses(); // Tải lại danh sách key mới sau khi đóng modal
};

el.btnCloseModal.addEventListener('click', closeModal);
el.btnCancelModal.addEventListener('click', closeModal);

// Gửi yêu cầu tạo License Key mới
el.createLicenseForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const days = parseInt(el.licenseDays.value);
    
    if (isNaN(days) || days <= 0) {
        return showToast('Số ngày không hợp lệ', 'error');
    }
    
    try {
        const res = await fetch(`${API_URL}/api/admin/licenses`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ days })
        });
        
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Tạo key bản quyền lỗi.');
        
        // Hiển thị Key được sinh ra
        el.generatedKeyText.textContent = data.license.key;
        el.generatedKeyContainer.classList.remove('hidden');
        showToast('Tạo Key bản quyền thành công!', 'success');
    } catch (err) {
        showToast(err.message, 'error');
    }
});

// Nút Copy Key được sinh ra
el.btnCopyGenKey.addEventListener('click', () => {
    copyToClipboard(el.generatedKeyText.textContent);
});

// Chạy khởi tạo ứng dụng khi load trang
window.addEventListener('DOMContentLoaded', async () => {
    lucide.createIcons();
    await checkSessionAndLoad();
});
