// src/db.ts
import { relations } from "drizzle-orm";
import { pgTable, text, timestamp, boolean, index, uuid } from "drizzle-orm/pg-core";
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as dotenv from "dotenv";

dotenv.config();

if (!process.env.DATABASE_URL) {
    console.error("❌ LỖI: Chưa cấu hình DATABASE_URL trong file .env");
    process.exit(1);
}

// 1. Khởi tạo Pool kết nối PostgreSQL
export const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 10, // Giới hạn connection pool trong môi trường production
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
});

// Bắt lỗi kết nối rảnh bị đứt đột ngột trong pool
pool.on("error", (err) => {
    console.error("❌ DATABASE POOL LỖI ĐỘT NGỘT:", err.message);
});

export const db = drizzle(pool);

// 2. Hàm kiểm tra kết nối Database khi khởi chạy
async function testConnection() {
    try {
        const client = await pool.connect();
        console.log("✅ DATABASE: Kết nối đến PostgreSQL thành công!");

        // Kiểm tra xem database có phản hồi nhanh không
        const res = await client.query("SELECT NOW()");
        console.log(`⏱️ Thời gian hệ thống DB: ${res.rows[0].now}`);

        client.release();
    } catch (err: any) {
        console.error("❌ DATABASE LỖI KẾT NỐI BAN ĐẦU: Kiểm tra lại cấu hình DATABASE_URL!");
        console.error(`👉 Chi tiết lỗi: ${err.message}`);
    }
}

// Chạy kiểm tra kết nối bất tuần tự lúc khởi tạo ứng dụng
testConnection();

// --- Định nghĩa Hệ thống Cơ sở dữ liệu (Schema) ---

// 1. Bảng User (Hợp nhất Better-Auth và phân quyền)
export const user = pgTable("user", {
    id: text("id").primaryKey(),
    name: text("name").notNull(),
    email: text("email").notNull().unique(),
    emailVerified: boolean("email_verified").default(false).notNull(),
    image: text("image"),
    role: text("role").default("user").notNull(), // Thêm phân quyền người dùng
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at")
        .defaultNow()
        .$onUpdate(() => new Date())
        .notNull(),
});

// 2. Bảng Session
export const session = pgTable(
    "session",
    {
        id: text("id").primaryKey(),
        expiresAt: timestamp("expires_at").notNull(),
        token: text("token").notNull().unique(),
        createdAt: timestamp("created_at").defaultNow().notNull(),
        updatedAt: timestamp("updated_at")
            .$onUpdate(() => new Date())
            .notNull(),
        ipAddress: text("ip_address"),
        userAgent: text("user_agent"),
        userId: text("user_id")
            .notNull()
            .references(() => user.id, { onDelete: "cascade" }),
    },
    (table) => [index("session_userId_idx").on(table.userId)],
);

// 3. Bảng Account (Lưu thông tin đăng nhập/OAuth của Better-Auth)
export const account = pgTable(
    "account",
    {
        id: text("id").primaryKey(),
        accountId: text("account_id").notNull(),
        providerId: text("provider_id").notNull(),
        userId: text("user_id")
            .notNull()
            .references(() => user.id, { onDelete: "cascade" }),
        accessToken: text("access_token"),
        refreshToken: text("refresh_token"),
        idToken: text("id_token"),
        accessTokenExpiresAt: timestamp("access_token_expires_at"),
        refreshTokenExpiresAt: timestamp("refresh_token_expires_at"),
        scope: text("scope"),
        password: text("password"),
        createdAt: timestamp("created_at").defaultNow().notNull(),
        updatedAt: timestamp("updated_at")
            .$onUpdate(() => new Date())
            .notNull(),
    },
    (table) => [index("account_userId_idx").on(table.userId)],
);

// 4. Bảng Verification (Lưu mã xác minh email/OTP)
export const verification = pgTable(
    "verification",
    {
        id: text("id").primaryKey(),
        identifier: text("identifier").notNull(),
        value: text("value").notNull(),
        expiresAt: timestamp("expires_at").notNull(),
        createdAt: timestamp("created_at").defaultNow().notNull(),
        updatedAt: timestamp("updated_at")
            .defaultNow()
            .$onUpdate(() => new Date())
            .notNull(),
    },
    (table) => [index("verification_identifier_idx").on(table.identifier)],
);

// 5. Bảng Licenses (Quản lý bản quyền phần mềm)
export const licenses = pgTable("licenses", {
    id: uuid("id").defaultRandom().primaryKey(),
    key: text("key").notNull().unique(),
    userId: text("user_id").references(() => user.id, { onDelete: "set null" }),
    hwid: text("hwid"),
    status: text("status").default("active").notNull(),
    expiresAt: timestamp("expires_at").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
});

// --- Ràng buộc Quan hệ Drizzle Relations ---

export const userRelations = relations(user, ({ many }) => ({
    sessions: many(session),
    accounts: many(account),
    licenses: many(licenses),
}));

export const sessionRelations = relations(session, ({ one }) => ({
    user: one(user, {
        fields: [session.userId],
        references: [user.id],
    }),
}));

export const accountRelations = relations(account, ({ one }) => ({
    user: one(user, {
        fields: [account.userId],
        references: [user.id],
    }),
}));

export const licensesRelations = relations(licenses, ({ one }) => ({
    user: one(user, {
        fields: [licenses.userId],
        references: [user.id],
    }),
}));

// --- Graceful Shutdown (Đóng Pool an toàn khi ngắt server) ---
const shutdown = async (signal: string) => {
    console.log(`\n⚠️ Nhận tín hiệu ${signal}. Đang đóng kết nối database pool...`);
    try {
        await pool.end();
        console.log("✅ Database pool đã được đóng thành công.");
        process.exit(0);
    } catch (err: any) {
        console.error("❌ Lỗi xảy ra khi đóng database pool:", err.message);
        process.exit(1);
    }
};

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));