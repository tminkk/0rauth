// src/index.ts
import { Hono } from "hono";
import { cors } from "hono/cors";
import { logger } from "hono/logger";
import { serve } from "@hono/node-server";
import { serveStatic } from "@hono/node-server/serve-static";
import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import * as dbSchema from "./db";
import { db, licenses, user } from "./db";
import { eq } from "drizzle-orm";
import * as dotenv from "dotenv";

dotenv.config();

// 1. Kiểm tra cấu hình môi trường bắt buộc
if (!process.env.BETTER_AUTH_SECRET) {
    console.error("❌ LỖI KHỞI CHẠY: Chưa cấu hình BETTER_AUTH_SECRET trong file .env");
    process.exit(1);
}

// 2. Khởi tạo Better-Auth với đầy đủ Schema để Drizzle adapter tự động đối chiếu
export const auth = betterAuth({
    database: drizzleAdapter(db, {
        provider: "pg",
        schema: dbSchema, // Nạp trực tiếp schema chứa user, session, account, verification
    }),
    secret: process.env.BETTER_AUTH_SECRET,
    emailAndPassword: {
        enabled: true,
        disableSignUp: true, // Vô hiệu hóa hoàn toàn chức năng đăng ký tài khoản mới từ API
    },
    user: {
        additionalFields: {
            role: {
                type: "string",
                defaultValue: "user",
            },
        },
    },
});

const app = new Hono();

// 3. Logger Middleware cho môi trường production
app.use("*", logger());

// 4. Cấu hình CORS tin cậy (Cho phép cấu hình các Origins qua env)
const allowedOrigins = process.env.ALLOWED_ORIGINS
    ? process.env.ALLOWED_ORIGINS.split(",")
    : ["*"];

app.use("*", cors({
    origin: (origin) => {
        if (allowedOrigins.includes("*") || allowedOrigins.includes(origin)) {
            return origin;
        }
        return allowedOrigins[0]; // Trả về origin tin cậy đầu tiên làm fallback
    },
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allowHeaders: ["Content-Type", "Authorization"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
    credentials: true,
}));

// Helper kiểm tra quyền Admin từ session Better-Auth
const checkAdmin = async (c: any) => {
    try {
        const session = await auth.api.getSession({
            headers: c.req.raw.headers
        });
        if (!session || !session.user || session.user.role !== "admin") {
            return null;
        }
        return session.user;
    } catch {
        return null;
    }
};

// 5. Middleware xử lý lỗi hệ thống tập trung (Global Error Handler)
app.onError((err, c) => {
    const cause = (err as any).cause;
    console.error(`❌ LỖI HỆ THỐNG SERVER: ${err.message}`);
    if (cause) console.error(`👉 NGUYÊN NHÂN CHÍNH:`, cause);

    return c.json({
        valid: false,
        error: "Lỗi Server Nội Bộ",
        details: err.message,
        cause: cause?.message || null
    }, 500);
});

// Chuyển hướng các route authentication đến Better-Auth handler
app.all("/api/auth/*", async (c) => {
    const res = await auth.handler(c.req.raw);
    return res;
});

// 6. API để Client/Phần mềm gọi lên kiểm tra bản quyền (Khóa HWID)
app.post("/api/verify-license", async (c) => {
    try {
        const body = await c.req.json<{ licenseKey?: string; hwid?: string }>().catch(() => null);
        if (!body || !body.licenseKey) {
            return c.json({ valid: false, error: "Thiếu thông tin License Key" }, 400);
        }

        const { licenseKey, hwid } = body;

        // Truy vấn thông tin key trong Database
        const result = await db.select().from(licenses).where(eq(licenses.key, licenseKey)).limit(1);
        const currentKey = result[0];

        if (!currentKey) {
            return c.json({ valid: false, error: "Key không hợp lệ hoặc không tồn tại" }, 404);
        }

        if (currentKey.status === "banned") {
            return c.json({ valid: false, error: "Key này đã bị khóa (Banned)" }, 403);
        }

        if (new Date() > new Date(currentKey.expiresAt)) {
            return c.json({ valid: false, error: "Key đã hết hạn sử dụng" }, 403);
        }

        // Logic bảo mật khóa HWID:
        // Nếu key đã được kích hoạt trước đó, bắt buộc phải truyền hwid và hwid phải trùng khớp
        if (currentKey.hwid) {
            if (!hwid || currentKey.hwid !== hwid) {
                return c.json({ valid: false, error: "Key đã được kích hoạt trên thiết bị khác" }, 403);
            }
        }

        // Nếu máy này là máy đầu tiên kích hoạt key, lưu lại HWID của họ luôn
        if (!currentKey.hwid && hwid) {
            await db.update(licenses).set({ hwid }).where(eq(licenses.key, licenseKey));
            currentKey.hwid = hwid; // Cập nhật local state để phản hồi chính xác trong response
        }

        return c.json({
            valid: true,
            message: "Xác thực bản quyền thành công!",
            expiresAt: currentKey.expiresAt,
            hwidBound: currentKey.hwid || null
        }, 200);

    } catch (err: any) {
        return c.json({
            valid: false,
            error: "Định dạng dữ liệu gửi lên không hợp lệ hoặc có lỗi xảy ra",
            details: err.message
        }, 400);
    }
});

// --- 7. BỘ API QUẢN TRỊ (ADMIN DASHBOARD API) ---

// Kích hoạt tài khoản Admin đầu tiên (Bootstrap)
app.post("/api/admin/promote-first-user", async (c) => {
    try {
        const body = await c.req.json<{ email?: string }>().catch(() => null);
        if (!body || !body.email) {
            return c.json({ success: false, error: "Thiếu email người dùng" }, 400);
        }

        const { email } = body;

        // 1. Kiểm tra xem hệ thống đã có admin nào chưa
        const admins = await db.select().from(user).where(eq(user.role, "admin")).limit(1);
        if (admins.length > 0) {
            return c.json({ success: false, error: "Hệ thống đã tồn tại quản trị viên. Chức năng bootstrap đã bị khóa." }, 403);
        }

        // 2. Tìm tài khoản người dùng theo email
        const targetUser = await db.select().from(user).where(eq(user.email, email)).limit(1);
        if (targetUser.length === 0) {
            return c.json({ success: false, error: "Không tìm thấy email tài khoản đã đăng ký này trong DB." }, 404);
        }

        // 3. Thăng cấp làm admin
        await db.update(user).set({ role: "admin" }).where(eq(user.email, email));

        return c.json({ success: true, message: `Thăng cấp quyền Admin thành công cho tài khoản ${email}!` }, 200);
    } catch (err: any) {
        return c.json({ success: false, error: "Lỗi hệ thống", details: err.message }, 500);
    }
});

// Lấy toàn bộ danh sách License Keys
app.get("/api/admin/licenses", async (c) => {
    const admin = await checkAdmin(c);
    if (!admin) {
        return c.json({ error: "Yêu cầu quyền Quản trị viên" }, 403);
    }

    const allLicenses = await db.select().from(licenses);
    return c.json(allLicenses);
});

// Tạo mới một key bản quyền
app.post("/api/admin/licenses", async (c) => {
    const admin = await checkAdmin(c);
    if (!admin) {
        return c.json({ error: "Yêu cầu quyền Quản trị viên" }, 403);
    }

    const body = await c.req.json<{ days?: number }>().catch(() => null);
    if (!body || !body.days || typeof body.days !== "number" || body.days <= 0) {
        return c.json({ error: "Số ngày hết hạn không hợp lệ" }, 400);
    }

    // Sinh key dạng 0RAUTH-XXXX-XXXX-XXXX ngẫu nhiên
    const randSeg = () => Math.random().toString(36).substring(2, 6).toUpperCase();
    const newKey = `0RAUTH-${randSeg()}-${randSeg()}-${randSeg()}`;

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + body.days);

    const [inserted] = await db.insert(licenses).values({
        key: newKey,
        expiresAt,
        status: "active"
    }).returning();

    return c.json({ success: true, license: inserted });
});

// Khóa hoặc mở khóa một key
app.post("/api/admin/licenses/ban", async (c) => {
    const admin = await checkAdmin(c);
    if (!admin) {
        return c.json({ error: "Yêu cầu quyền Quản trị viên" }, 403);
    }

    const body = await c.req.json<{ licenseId?: string; status?: "active" | "banned" }>().catch(() => null);
    if (!body || !body.licenseId || !body.status || (body.status !== "active" && body.status !== "banned")) {
        return c.json({ error: "Thông tin gửi lên không hợp lệ" }, 400);
    }

    await db.update(licenses).set({ status: body.status }).where(eq(licenses.id, body.licenseId));

    return c.json({ success: true, message: "Cập nhật trạng thái key thành công!" });
});

// Reset HWID (Mở khóa liên kết thiết bị phần cứng)
app.post("/api/admin/licenses/reset-hwid", async (c) => {
    const admin = await checkAdmin(c);
    if (!admin) {
        return c.json({ error: "Yêu cầu quyền Quản trị viên" }, 403);
    }

    const body = await c.req.json<{ licenseId?: string }>().catch(() => null);
    if (!body || !body.licenseId) {
        return c.json({ error: "Thiếu ID key bản quyền" }, 400);
    }

    await db.update(licenses).set({ hwid: null }).where(eq(licenses.id, body.licenseId));

    return c.json({ success: true, message: "Đã xóa liên kết phần cứng HWID của key." });
});

// Xóa vĩnh viễn key bản quyền
app.delete("/api/admin/licenses", async (c) => {
    const admin = await checkAdmin(c);
    if (!admin) {
        return c.json({ error: "Yêu cầu quyền Quản trị viên" }, 403);
    }

    const body = await c.req.json<{ licenseId?: string }>().catch(() => null);
    if (!body || !body.licenseId) {
        return c.json({ error: "Thiếu ID key bản quyền" }, 400);
    }

    await db.delete(licenses).where(eq(licenses.id, body.licenseId));

    return c.json({ success: true, message: "Đã xóa vĩnh viễn key bản quyền khỏi hệ thống." });
});

app.get("/test", (c) => c.text("Hono Server đang sống và nhận request tốt!"));

// --- 8. PHỤC VỤ GIAO DIỆN TĨNH (STATIC DASHBOARD FRONTEND) ---
app.get("/*", serveStatic({ root: "./public" }));

// Khởi chạy server ở cổng 3000
const port = 3000;
serve({
    fetch: app.fetch,
    port
}, (info) => {
    console.log(`🚀 SERVER: Hono đang chạy tại http://localhost:${info.port}`);
});